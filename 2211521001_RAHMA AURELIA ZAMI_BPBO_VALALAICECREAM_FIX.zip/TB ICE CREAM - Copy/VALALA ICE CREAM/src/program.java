// pernyataan impor, mengimpor paket dan kelas yang diperlukan untuk berbagai fungsi, termasuk penanganan tanggal, input/output, operasi SQL, dan antrian.
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.sql.*;
import java.io.File;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
// import com.mysql.cj.protocol.Resultset;

public class program { // deklarasi kelas


    public static void main(String[] args) throws SQLException { // method main

        // Method Date
        Date tanggal = new Date(); // pemformatan tanggal
        SimpleDateFormat ft = new SimpleDateFormat("E yyyy.MM.dd ', jam' hh:mm:ss a");

        // koneksi ke database
        String url = "jdbc:mysql://localhost:3306/valala";
 
        //input pengguna dan penanganan menu
        int pilihann;
        try (Scanner terimaInput = new Scanner(System.in)) {
            boolean menu = true;

            transaksi trs = new transaksi(0, 0);
            antrian antrian = new antrian();

            try { // koneksi database dan login
                Class.forName("com.mysql.cj.jdbc.Driver");
                DriverManager.getConnection(url, "root", "");
                System.out.println("Class Driver ditemukan");
                Login login = new Login();
                login.masukkanDetails();
                while (menu) { //opsi tampilan menu ketika program dijalankan
                    System.out.println("\n");
                    System.out.println("\n---------------------------------------------");
                    System.out.println("             Selamat datang di ");
                    System.out.println("             Valala Ice Cream  ");
                    System.out.println("Tanggal : " + ft.format(tanggal));
                    System.out.println("---------------------------------------------");
                    System.out.println("1. Lihat Data");
                    System.out.println("2. Beli (tambah data)");
                    System.out.println("3. Ubah nama menu(update data)");
                    System.out.println("4. Hapus Data");
                    System.out.println("5. Cari Data");
                    System.out.println("6. Tampilkan Antrian");
                    System.out.println("7. Hapus Antrian Awal");
                    System.out.println("8. Hapus Seluruh Antrian");
                    System.out.println("9. Selesai");
                    System.out.println("---------------------------------------------");

                    System.out.print("\nPilihan anda (1/2/3/4/5/6/7/8/9): ");
                    pilihann = terimaInput.nextInt();

                    // Percabangan (switch case)
                    switch (pilihann) {
                        case 1: // melihat data yang sudah masuk
                            trs.view();
                            break;
                        case 2: // menyimpan data
                            trs.save();
                            break;
                        case 3: // updata data di database
                            trs.update();
                            break;
                        case 4: // hapus data di database
                            trs.delete();
                            break;
                        case 5: // mencari data di database
                            trs.search();
                            break;
                        case 6: // Hapus Antrian Awal
                            antrian.tampilkanAntrian();
                            break;
                        case 7: // Hapus Antrian Awal
                            antrian.hapusAntrianTerbaru();
                            break;
                        case 8:
                            antrian.hapusSeluruhAntrian();
                            break;
                        case 9:
                            menu = false;
                            break;

                        default: // exception jika data yang dicari tidak tersedia
                            System.err.println("\nInput tidak ditemukan\nSilakan pilih [1-9]");
                            break;
                    }
                }

                //penanganan pengecualian
            } catch (ClassNotFoundException ex) {
                System.err.println("Driver Error");
                System.exit(0);
            }
            // exeption SQL
            catch (SQLException e) {
                System.err.println("Tidak berhasil koneksi");
                System.err.println(e.getMessage());
            }

            catch (Exception e) {
                System.err.println("Error Program.");
                System.err.println(e.getMessage());
                //shutdownhook
                Runtime.getRuntime().addShutdownHook(new Thread () {

                    @Override
                    public void run() {
                        System.out.println("SHUTDOWN");
                        try {
                            antrian.hapusSeluruhAntrian();

                        } catch (SQLException e){
                            //TODO AutoGenerated catch block
                            e.printStackTrace();
                        }

                    }
                });
            }
        }
        System.out.println("\nSelesai\n"); //pengakhiran program

        
    }

}
