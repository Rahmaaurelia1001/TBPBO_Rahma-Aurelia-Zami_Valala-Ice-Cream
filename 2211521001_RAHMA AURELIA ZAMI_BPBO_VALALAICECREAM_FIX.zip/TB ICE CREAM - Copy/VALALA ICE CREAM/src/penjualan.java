//Interface Penjualan
public interface penjualan {

    public void kasir();
    public void namamenu();
    public void ukuran();
    public void hargamenu();
    public void jumlah();
    public int subtotal();
    public int diskon();
    public int totalharga();
    public void tampil();
}